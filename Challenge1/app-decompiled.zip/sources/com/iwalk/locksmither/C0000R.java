package com.iwalk.locksmither;

/* renamed from: com.iwalk.locksmither.R */
public final class C0000R {

    /* renamed from: com.iwalk.locksmither.R$drawable */
    public static final class drawable {
        public static final int launch_background = 2130771968;
    }

    /* renamed from: com.iwalk.locksmither.R$mipmap */
    public static final class mipmap {
        public static final int ic_launcher = 2130837504;
    }

    /* renamed from: com.iwalk.locksmither.R$style */
    public static final class style {
        public static final int LaunchTheme = 2130903040;
    }
}
