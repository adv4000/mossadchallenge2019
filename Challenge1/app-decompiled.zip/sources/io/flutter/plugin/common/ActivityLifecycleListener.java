package io.flutter.plugin.common;

public interface ActivityLifecycleListener {
    void onPostResume();
}
